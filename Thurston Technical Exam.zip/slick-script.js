$(document).ready(function(){
    $('.slider-row').slick({
        arrows: false,
        dots: true,
        infinite: false,
        slidesToShow:4,
        slidesToScroll: 1
    });
    });

    $('.hero-section').slick({
        dots: true,
        arrows: true,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear',
        draggable: true,
        autoplay: true
    });